const Room = require('../models/Room');

/**
 * Room Controller
 * Handles CRUD operations for room management
 * Endpoints: GET, POST, PUT, DELETE rooms
 */

/**
 * GET /api/admin/rooms
 * Get all rooms in the resort
 */
exports.getAllRooms = async (req, res) => {
  try {
    const rooms = await Room.find();
    res.json(rooms);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

/**
 * GET /api/admin/rooms/:id
 * Get a specific room by ID
 */
exports.getRoomById = async (req, res) => {
  try {
    const room = await Room.findById(req.params.id);
    if (!room) return res.status(404).json({ error: 'Room not found' });
    res.json(room);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

/**
 * POST /api/admin/rooms
 * Create a new room (Admin only)
 * Body: { name, capacity, price, description, status }
 * Validation: capacity must be > 0, price must be >= 0
 */
exports.createRoom = async (req, res) => {
  try {
    const { name, capacity, price, description, status } = req.body;

    // ============================================
    // BACKEND VALIDATION
    // ============================================
    if (!name || name.trim() === '') {
      return res.status(400).json({ error: 'Room Name is required' });
    }
    if (name.trim().length < 2) {
      return res.status(400).json({ error: 'Room Name must be at least 2 characters' });
    }

    if (capacity === undefined || capacity === null || capacity === '') {
      return res.status(400).json({ error: 'Capacity is required' });
    }
    const parsedCapacity = parseInt(capacity);
    if (isNaN(parsedCapacity)) {
      return res.status(400).json({ error: 'Capacity must be a valid number' });
    }
    if (parsedCapacity <= 0) {
      return res.status(400).json({ error: 'Capacity must be greater than 0' });
    }

    if (price === undefined || price === null || price === '') {
      return res.status(400).json({ error: 'Price per Night is required' });
    }
    const parsedPrice = parseFloat(price);
    if (isNaN(parsedPrice)) {
      return res.status(400).json({ error: 'Price must be a valid number' });
    }
    if (parsedPrice < 0) {
      return res.status(400).json({ error: 'Price cannot be negative' });
    }

    const room = new Room({ 
      name: name.trim(), 
      capacity: parsedCapacity, 
      price: parsedPrice, 
      description, 
      status 
    });
    await room.save();
    res.status(201).json(room);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

/**
 * PUT /api/admin/rooms/:id
 * Update room details (Admin only)
 * Validation: capacity must be > 0, price must be >= 0
 */
exports.updateRoom = async (req, res) => {
  try {
    const { name, capacity, price, description, status } = req.body;

    // ============================================
    // BACKEND VALIDATION
    // ============================================
    if (name !== undefined && name !== null) {
      if (name.trim() === '') {
        return res.status(400).json({ error: 'Room Name is required' });
      }
      if (name.trim().length < 2) {
        return res.status(400).json({ error: 'Room Name must be at least 2 characters' });
      }
    }

    if (capacity !== undefined && capacity !== null) {
      const parsedCapacity = parseInt(capacity);
      if (isNaN(parsedCapacity)) {
        return res.status(400).json({ error: 'Capacity must be a valid number' });
      }
      if (parsedCapacity <= 0) {
        return res.status(400).json({ error: 'Capacity must be greater than 0' });
      }
    }

    if (price !== undefined && price !== null) {
      const parsedPrice = parseFloat(price);
      if (isNaN(parsedPrice)) {
        return res.status(400).json({ error: 'Price must be a valid number' });
      }
      if (parsedPrice < 0) {
        return res.status(400).json({ error: 'Price cannot be negative' });
      }
    }

    const updateData = { name, capacity, price, description, status };
    // Remove undefined values
    Object.keys(updateData).forEach(key => updateData[key] === undefined && delete updateData[key]);

    const room = await Room.findByIdAndUpdate(req.params.id, updateData, { new: true });
    if (!room) return res.status(404).json({ error: 'Room not found' });
    res.json(room);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

/**
 * DELETE /api/admin/rooms/:id
 * Delete a room (Admin only)
 */
exports.deleteRoom = async (req, res) => {
  try {
    const room = await Room.findByIdAndDelete(req.params.id);
    if (!room) return res.status(404).json({ error: 'Room not found' });
    res.json({ message: 'Room deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ============================================
// STAFF ASSIGNMENT ENDPOINTS
// ============================================

/**
 * PUT /api/admin/rooms/:id/assign-staff
 * Assign a staff member to check/maintain a room (Admin only)
 * Body: { staffId, notes? }
 * Returns: Updated room with assigned staff
 */
exports.assignStaffToRoom = async (req, res) => {
  try {
    const { staffId, notes } = req.body;
    
    // Validate inputs
    if (!staffId) {
      return res.status(400).json({ error: 'Staff ID is required' });
    }

    // Find room and add staff to assignedStaff array
    const room = await Room.findByIdAndUpdate(
      req.params.id,
      {
        $push: {
          assignedStaff: {
            staffId,
            notes,
            assignedDate: new Date()
          }
        }
      },
      { new: true }
    ).populate('assignedStaff.staffId', 'name email');

    if (!room) return res.status(404).json({ error: 'Room not found' });
    res.json(room);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

/**
 * PUT /api/admin/rooms/:id/remove-staff/:staffId
 * Remove a staff member from room assignment (Admin only)
 * Returns: Updated room with staff removed
 */
exports.removeStaffFromRoom = async (req, res) => {
  try {
    const { id, staffId } = req.params;

    // Find room and remove staff from assignedStaff array
    const room = await Room.findByIdAndUpdate(
      id,
      {
        $pull: {
          assignedStaff: { staffId }
        }
      },
      { new: true }
    ).populate('assignedStaff.staffId', 'name email');

    if (!room) return res.status(404).json({ error: 'Room not found' });
    res.json(room);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

/**
 * GET /api/admin/rooms/:id/staff
 * Get all staff assigned to a room
 * Returns: Array of assigned staff with details
 */
exports.getRoomStaff = async (req, res) => {
  try {
    const room = await Room.findById(req.params.id).populate('assignedStaff.staffId');
    
    if (!room) return res.status(404).json({ error: 'Room not found' });
    res.json(room.assignedStaff);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
