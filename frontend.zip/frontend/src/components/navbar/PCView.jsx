// src/components/navbar/PCView.jsx
import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import EditProfileModal from './EditProfileModal';

function PCView({ userData, userRole, getAvatarSrc, onViewProfile, onEditProfile, onLogout }) {
  const [showMainDropdown, setShowMainDropdown] = useState(false);
  const [showViewDropdown, setShowViewDropdown] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [avatarError, setAvatarError] = useState({});
  
  const mainDropdownRef = useRef(null);
  const viewDropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (mainDropdownRef.current && !mainDropdownRef.current.contains(event.target)) {
        setShowMainDropdown(false);
      }
      if (viewDropdownRef.current && !viewDropdownRef.current.contains(event.target)) {
        setShowViewDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getFirstName = () => userData?.name ? userData.name.split(' ')[0] : '';

  // Handle avatar load error
  const handleAvatarError = (type) => {
    console.log(`Avatar failed to load for ${type}:`, getAvatarSrc());
    setAvatarError(prev => ({ ...prev, [type]: true }));
  };

  // View Profile Dropdown - WITH FULL DESIGN
  const ViewProfileDropdown = () => {
    const avatarSrc = getAvatarSrc();
    const hasAvatar = avatarSrc && !avatarError['view'];
    
    return (
      <div className="pc-dropdown view-dropdown" ref={viewDropdownRef}>
        <div className="view-dropdown-header">
          <div className="view-dropdown-avatar">
            {hasAvatar ? (
              <img 
                src={avatarSrc} 
                alt={userData?.name} 
                onError={() => handleAvatarError('view')}
              />
            ) : (
              <span>{userData?.name?.charAt(0).toUpperCase()}</span>
            )}
          </div>
          <div className="view-dropdown-info">
            <div className="view-dropdown-name">{userData?.name}</div>
            <div className="view-dropdown-email">{userData?.email}</div>
          </div>
        </div>
        
        {userData?.phone && (
          <div className="view-dropdown-detail">
            <span className="detail-icon">📞</span>
            <span className="detail-text">{userData.phone}</span>
          </div>
        )}
        
        {userData?.address && (
          <div className="view-dropdown-detail">
            <span className="detail-icon">📍</span>
            <span className="detail-text">{userData.address}</span>
          </div>
        )}
        
        {userData?.googleId && (
          <div className="view-dropdown-google">Connected with Google</div>
        )}
        
        <div className="view-dropdown-actions">
          <button className="view-dropdown-edit-btn" onClick={() => {
            setShowViewDropdown(false);
            setShowEditModal(true);
          }}>
            Edit
          </button>
        </div>
      </div>
    );
  };

  // Get avatar for main profile button
  const getMainAvatar = () => {
    const avatarSrc = getAvatarSrc();
    if (!avatarSrc || avatarError['main']) {
      return (
        <span className="avatar-initials">
          {userData?.name?.charAt(0).toUpperCase()}
        </span>
      );
    }
    return (
      <img 
        src={avatarSrc} 
        alt={userData?.name} 
        className="avatar-img"
        onError={() => handleAvatarError('main')}
      />
    );
  };

  return (
    <div className="nav-right desktop-only">
      {userData ? (
        <>
          {(userRole === 'admin' || userRole === 'staff') && (
            <Link to="/dashboard" className="dashboard-link">Dashboard</Link>
          )}
          
          {/* Profile Button with Avatar */}
          <div className="dropdown-container" ref={mainDropdownRef}>
            <button 
              onClick={() => setShowMainDropdown(!showMainDropdown)} 
              className="user-profile-btn"
            >
              <span className="user-name">{getFirstName()}</span>
              <div className="avatar-with-indicator">
                <div className="avatar-circle">
                  {getMainAvatar()}
                </div>
                <span className="avatar-arrow">▼</span>
              </div>
            </button>

            {/* Main Dropdown Menu - WITH FULL DESIGN */}
            {showMainDropdown && (
              <div className="pc-dropdown main-dropdown">
                <button className="dropdown-item" onClick={() => {
                  setShowMainDropdown(false);
                  setShowViewDropdown(true);
                  // Reset avatar error for view dropdown when opening
                  setAvatarError(prev => ({ ...prev, view: false }));
                }}>
                  <span className="dropdown-icon">👤</span>
                  View Profile
                </button>
                {(userRole === 'admin' || userRole === 'staff') && (
                  <Link to="/dashboard" className="dropdown-item" onClick={() => setShowMainDropdown(false)}>
                    <span className="dropdown-icon">📋</span>
                    Dashboard
                  </Link>
                )}
                <button className="dropdown-item logout" onClick={() => {
                  setShowMainDropdown(false);
                  onLogout();
                }}>
                  <span className="dropdown-icon">↪</span>
                  Sign Out
                </button>
              </div>
            )}
          </div>

          {/* View Profile Dropdown */}
          {showViewDropdown && <ViewProfileDropdown />}

          {/* Edit Profile Modal */}
          <EditProfileModal 
            isOpen={showEditModal}
            onClose={() => setShowEditModal(false)}
            userData={userData}
            getAvatarSrc={getAvatarSrc}
            onSave={onEditProfile}
          />
        </>
      ) : (
        <div className="auth-buttons">
          <Link to="/login" className="login-link">Login</Link>
          <Link to="/register" className="register-link">Sign In</Link>
        </div>
      )}
    </div>
  );
}

export default PCView;